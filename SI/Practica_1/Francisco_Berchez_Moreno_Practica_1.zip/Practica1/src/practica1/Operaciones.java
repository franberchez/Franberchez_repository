/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;

/**
 *
 * @author frankark
 */
public class Operaciones {
    public static int factorial(int value) {
        int aux = 1;
        if (value < 0) {
            return 0;
        }
        if (value == 0) {
            return 1;
        }

        for (int i = 1; i <= value; i++) {
            aux = aux * i;
        }
        return aux;
    }
}

class UsaOperacion {
    public static void main(String args[])
    {
        int value = 5;
        int resultado;
        
        resultado = Operaciones.factorial(value);
        System.out.println("El resultado del factorial es = " + resultado);
    }
}
