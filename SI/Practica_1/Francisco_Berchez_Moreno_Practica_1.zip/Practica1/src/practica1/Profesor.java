/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;

/**
 *
 * @author frankark
 */
public class Profesor extends Persona{
    String universidad;
    int id_profesor;

    public Profesor() {
        this.universidad = "";
        this.id_profesor = 0;
    }
    
    public String getUniversidad() {
        return universidad;
    }

    public int getId_profesor() {
        return id_profesor;
    }

    public void setUniversidad(String universidad) {
        this.universidad = universidad;
    }

    public void setId_profesor(int id_profesor) {
        this.id_profesor = id_profesor;
    }
}
