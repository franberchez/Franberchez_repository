/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;

/**
 *
 * @author frankark
 */
public class Practica1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Profesor p = new Profesor();
        p.setUniversidad("UCO");
        p.setId_profesor(1);
        p.setName("Francisco");
        p.setSurname("Bérchez");
        p.setAge(20);
        
        System.out.println("El profesor " + p.getName() + " " + p.getSurname() + " con edad " + p.getAge() + " trabaja en la universidad " + p.getUniversidad() + " y tiene un id de profesor " + p.getId_profesor());
    }
    
}
