//dados.h
//That program make a class with the name Dados

/*
#include <iostream>
using namespace std;
*/

//La clase dados representa el lanzamiento de dos dados

#ifndef DADOS_H
#define DADOS_H

class Dados{ //REVISAR QUE SON LAS CLASES NO TENGO MUY CLARO QUE SON NI COMO SE FORMAN

	private:  //Datos de la clase que se encuentra en la parte privada

		int d1_;
		int d2_;
		int cont1_;
		int cont2_;
		float suma1_;
		float suma2_;
		int v1_[5];
		int v2_[5];

	public:  //Metodos de la clase que se encuentran en la parte publica

		Dados();// el constructor no devuelve nada NO TENGO MUY CLARO COMO DESARROLLARLO COMO FUNCION
		void lanzamiento();

		inline int getDado1() const {return d1_;}
		inline int getDado2() const {return d2_;}

		bool setDado1(int num);
		bool setDado2(int num);

		inline int getSuma() const {return d1_+d2_;}
		int getDiferencia();

		inline int getLanzamientos1() const {return cont1_;}
		inline int getLanzamientos2() const {return cont2_;}

		float getMedia1();
		float getMedia2();
		void getUltimos1(int v[5]);
		void getUltimos2(int v[5]);
		//float getsumatotal1(){return suma1_;}
		//float getsumatotal2(){return suma2_;}

};//EL PUNTOY COMA DEL FINAL DEL CORCHETE ES IMPORTANTISIMO PARA QUE FUNCIONE CORRECTAMENTE LA CLASE

#endif