//helloworld.cc
//A program that prints the inmortal saying "hello world"

#include <iostream> //fijate que no termina en .h

using namespace std; //me ahorra tener que poner ::std

int main(){

	cout<<"hello world\n";
}