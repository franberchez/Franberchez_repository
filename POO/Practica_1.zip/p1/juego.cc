//juego.cc
//That program make diferent operatiions that we can do whit two dices

#include <iostream>
#include "dados.h"//ESTA ES LA FORMA CORRECTA

//using namespace std;  NO ES RECOMENDABLE USARLO
//#include <dados.h> ASI NO SE PONE

int main(){

	Dados d; //Una vez declaramos la clase dados se hace automaticamente el contructor que no devuelve nada solo cambia el valor de los dados a 1
	int num;
	int res;
	int i;
	int total;
	int v1[5];
	int v2[5];

		//std::cout<<"El dado numero 1 tiene el valor = "<<d.getDado1()<<std::endl;
		//std::cout<<"El dado numero 2 tiene el valor = "<<d.getDado2()<<std::endl;

		d.lanzamiento();

		//std::cout<<"El nuevo valor de los dados una vez realizamos un lanzamiento es el siguiente:\n";

		std::cout<<"El dado numero 1 tiene el valor = "<<d.getDado1()<<std::endl;// MIRAR CON CUIDADO EL INICIO Y EL FINAL DE COUT
		std::cout<<"El dado numero 2 tiene el valor = "<<d.getDado2()<<std::endl;

		std::cout<<"Cuantas veces quiere lanzar el dado 1"<<std::endl;
		std::cin>>total;


		for ( i=0; i<total; i++){

			std::cout<<"Introduzca el valor del primer dado: "<<std::endl;
			std::cin>>num;
				res=d.setDado1(num);

					if(res==true){
						std::cout<<"El valor del dado numero 1 esta entre los valores 1 y 6\n";
					}

					else {
						std::cout<<"El valor del dado numero 1 no esta entre los valores 1 y 6\n";
					}

				std::cout<<"El dado numero 1 tiene el valor = "<<d.getDado1()<<std::endl;
		}

		std::cout<<"El numero de lanzamientos del dado 1 es = "<<d.getLanzamientos1()<<std::endl;
		std::cout<<"El valor de la media del dado 1 es = "<<d.getMedia1()<<std::endl;



		std::cout<<"Cuantas veces quiere lanzar el dado 2"<<std::endl;
		std::cin>>total;

		for (i=0; i<total; i++){

			std::cout<<"Introduzca el valor del segundo dado: "<<std::endl;
			std::cin>>num;
				res= d.setDado2(num);


					if(res==true){
						std::cout<<"El valor del dado numero 2 esta entre los valores 1 y 6\n";
					}

					else {
						std::cout<<"El valor del dado numero 2 no esta entre los valores 1 y 6\n";
					}
				
				std::cout<<"El dado numero 2 tiene el valor = "<<d.getDado2()<<std::endl;

		}

		std::cout<<"El numero de lanzamientos del dado 2 es = "<<d.getLanzamientos2()<<std::endl;
		std::cout<<"El valor de la media del dado 2 es = "<<d.getMedia2()<<std::endl;

		//std::cout<<"El valor de la suma de los dados es = "<<d.getSuma()<<std::endl;

		//std::cout<<"El valor de la diferencia de los dados es = "<<d.getDiferencia()<<std::endl;

		std::cout<<"Los ultimos 5 valores del dado 1 son:\n";
		d.getUltimos1(v1);

			for (i=0; i<5; i++){
				std::cout<<"v[i]= "<<v1[i]<<std::endl;
			}

		std::cout<<"Los ultimos 5 valores del dado 1 son:\n";
		d.getUltimos2(v2);

			for (i=0; i<5; i++){
				std::cout<<"v[i]= "<<v2[i]<<std::endl;
			}



return 0;

}



			/*ERROR

			std::cout<<"El valor del dado 1 es = "<<d.d1_;

			dados.h:18:7: error: ‘int Dados::d1_’ es privado
   			int d1_;
       			^
			juego.cc:19:46: error: desde este contexto
    		std::cout<<"El valor del dado 1 es = "<<d.d1_;

    		*/