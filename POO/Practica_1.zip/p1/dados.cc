#include <iostream>
#include <ctime>
#include <cstdlib>
#include "dados.h"

Dados::Dados(){
	srand(time(NULL));

	d1_=1;
	d2_=1;

	cont1_=0;
	cont2_=0;
	suma1_=0;
	suma2_=0;

	for (int i=4; i>=0; i--){
		v1_[i]=0;
		v2_[i]=0;
	}
}

void Dados::lanzamiento(){

	d1_=(rand()%6)+1;
	d2_=(rand()%6)+1;

	cont1_=cont1_+1;
	cont2_=cont2_+1;

	suma1_=suma1_+d1_;
	suma2_=suma2_+d2_;

	for (int i=4; i>=1; i--){
		v1_[i]=v1_[i-1];
	}

	v1_[0]=d1_;

	for (int i=4; i>=1; i--){
		v2_[i]=v2_[i-1];
	}

	v2_[0]=d2_;
}

bool Dados::setDado1(int num){
	if ((num>=1)&&(num<=6)){
		d1_=num;
		cont1_=cont1_+1;
		suma1_=suma1_+d1_;

			for (int i=4; i>=1; i--){
				v1_[i]=v1_[i-1];
			}

			v1_[0]=d1_;

		return true;
	}

	else {
		return false;
	}
}

bool Dados::setDado2(int num){
	if ((num>=1)&&(num<=6)){
		d2_=num;
		cont2_= cont2_+1;
		suma2_=suma2_+d2_;

			for (int i=4; i>=1; i--){
				v2_[i]=v2_[i-1];
			}

			v2_[0]=d2_;

		return true;
	}

	else {
		return false;
	}
}

int Dados::getDiferencia(){

	if (d1_>d2_){
		return d1_-d2_;
	}

	else{
		return d2_-d1_;
	}
}


float Dados::getMedia1(){
	if(cont1_==0){
		return 0;
	}

	return suma1_/cont1_;

}

float Dados::getMedia2(){
	if(cont2_==0){
		return 0;
	}

	return suma2_/cont2_;
}

void Dados::getUltimos1(int v[5]){
	int i;

		for (i=0; i<5; i++){
			v[i]=v1_[i];
		}
}

void Dados::getUltimos2(int v[5]){
	int i;

		for (i=0; i<5; i++){
			v[i]=v2_[i];
		}
}