//guess.cc
//Generate a random number between 1 and 10

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
 
int main(){
	int i;
	int num;

		srand(time (NULL));
		num = 1+rand()%(11-1);

		cout<<"Introduce un numero: "<<endl;
		cin>>i;


	while(i!=num){

		if (i<num){
		cout<<"El numero "<<i<<" "<<"es menor que el numero aleatorio\n";

		}

		if (i>num){
			cout<<"El numero "<<i<<" "<<"es mayor que el numero aleatorio\n";
		}

		cout<<"Introduce otro numero: "<<endl;
		cin>>i;

	}

	cout<<"El numero num = "<<num<<" "<<"es el mismo que el mismo que su numero introducido\n";

	return 0;
}