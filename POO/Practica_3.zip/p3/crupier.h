#ifndef CRUPIER_H_
#define CRUPIER_H_

#include "persona.h"
#include <string>

class Crupier: public Persona{

	private:

		std::string DNI_;
		std::string codigo_;
		std::string nombre_;
		std::string apellidos_;
		int edad_;
		std::string direccion_;
		std::string localidad_;
		std::string provincia_;
		std::string pais_;


	public:

		Crupier(std::string dni, std::string codigo, std::string nombre="", std::string apellidos="", int edad=0, std::string direccion="", std::string localidad="", std::string provincia="", std::string pais=""): Persona(dni, nombre, apellidos, edad, direccion, localidad, provincia, pais)
		{codigo_=codigo;};

		inline std::string getCodigo() const {return codigo_;};
		inline void setCodigo(std::string cad) {codigo_=cad;};

};


#endif