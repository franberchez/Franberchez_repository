#include <iostream>
#include <list>
#include "jugador.h"
#include <fstream>
#include <cstdlib>
#include <cstring>
using namespace std;

void Jugador::setApuestas(){

	apuestas_.clear();

	string nombre= (getDNI()+".txt");
	ifstream fichero(nombre.c_str());
		
		if(fichero.fail()){
			cout<<"error al abrir el fichero"<<endl;
			exit(-1);
		}

		struct Apuesta aux;
		string tipo, valor, cantidad;
		string cadena;

		while( !fichero.eof() ){

			getline(fichero, tipo, ',');

				if(strcmp(tipo.c_str(),cadena.c_str())==0){
					break;
				}

			aux.tipo = atoi(tipo.c_str());


			getline(fichero, valor, ',');
			aux.valor = valor;

			getline(fichero, cantidad);
			aux.cantidad = atoi(cantidad.c_str());

			apuestas_.push_back(aux);
		}

	fichero.close();
}