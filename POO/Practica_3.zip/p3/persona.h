#ifndef PERSONA_H_
#define PERSONA_H_
#include <string>

class Persona{

	private:

		std::string DNI_;
		std::string nombre_;
		std::string apellidos_;
		int edad_;
		std::string direccion_;
		std::string localidad_;
		std::string provincia_;
		std::string pais_;

	public:

		Persona(std::string dni, std::string nombre="", std::string apellidos="", int edad_=0, std::string direccion="", std::string localidad="", std::string provincia="", std::string pais="");
		inline void setDNI(std::string cad) {DNI_=cad;}
		inline std::string getDNI() const {return DNI_;}

		inline void setNombre(std::string cad) {nombre_=cad;}
		inline std::string getNombre() const {return nombre_;}

		inline void setApellidos(std::string cad) {apellidos_=cad;}
		inline std::string getApellidos() const {return apellidos_;}

		bool setEdad(int num);
		inline int getEdad() const {return edad_;}

		inline void setDireccion(std::string cad) {direccion_=cad;}
		inline std::string getDireccion() const {return direccion_;}

		inline void setLocalidad(std::string cad) {localidad_=cad;}
		inline std::string getLocalidad() const {return localidad_;}

		inline void setProvincia(std::string cad) {provincia_=cad;}
		inline std::string getProvincia() const {return provincia_;}

		inline void setPais(std::string cad) {pais_=cad;}
		inline std::string getPais() const {return pais_;}

		inline std::string getApellidosyNombre() const {return apellidos_+", "+nombre_;}
		bool mayor();


};

#endif