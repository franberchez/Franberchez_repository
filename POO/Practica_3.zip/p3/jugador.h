#ifndef JUGADOR_H_
#define JUGADOR_H_

#include "persona.h"
#include <string>
#include <list>

struct Apuesta{
	int tipo;
	std::string valor;
	int cantidad;
};


class Jugador: public Persona{

	private:

		int dinero_;
		std::string codigo_;
		std::list<struct Apuesta> apuestas_;

	public:

		Jugador(std::string dni, std::string codigo, std::string nombre="", std::string apellidos="", 
			    int edad=0, std::string direccion="", std::string localidad="", std::string provincia="", 
			    std::string pais=""): Persona(dni, nombre, apellidos, edad, direccion, localidad, provincia, pais)
		{dinero_=1000; codigo_=codigo;};

		inline void setCodigo(std::string cad) {codigo_=cad;};
		inline std::string getCodigo() const {return codigo_;};

		inline void setDinero(int dinero) {dinero_=dinero;};
		inline int getDinero() const {return dinero_;};

		inline std::list<struct Apuesta> getApuestas() {return apuestas_;};
		void setApuestas();

};





#endif