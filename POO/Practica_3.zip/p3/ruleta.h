#ifndef RULETA_H_
#define RULETA_H_

#include <list>
#include "crupier.h"
#include "jugador.h"
#include "persona.h"

class Ruleta{

	private:
		int banca_;
		int bola_;
		std::list <Jugador> jugadores_;
		Crupier crupier_;

	public:

		Ruleta(Crupier c):crupier_(c){bola_=-1; banca_=1000000;};

		inline int getBanca() const {return banca_;};
		inline int getBola() const {return bola_;};

		bool setBanca(int valor);
		bool setBola(int bola);

		inline Crupier getCrupier() const {return crupier_;};
		inline void setCrupier(Crupier c) {crupier_= c;};

		inline std::list<Jugador> getJugadores() const {return jugadores_;};
		bool addJugador(Jugador j);

		int deleteJugador(std::string DNI);
		int deleteJugador(Jugador j);

		void escribeJugadores();
		void leeJugadores();

		void giraRuleta();

		void getPremios();

		void apuestaSencilla(struct Apuesta p, int &dinero);
		void apuestaRojoNegro(struct Apuesta p, int &dinero);
		void apuestaParImpar(struct Apuesta p, int &dinero);
		void apuestaAltoBajo(struct Apuesta p, int &dinero);
		std::string color(int bola);
		std::string par_impar(int bola);
		std::string alto_bajo(int bola);

};

#endif