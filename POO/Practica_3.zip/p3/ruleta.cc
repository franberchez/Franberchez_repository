#include <iostream>
#include <fstream>
#include <list>
#include <string>
#include <cstdlib>
#include "ruleta.h"
#include "jugador.h"
#include "persona.h"
#include <ctime>
using namespace std;

bool Ruleta::setBanca(int valor){

	if(valor>0){
		banca_ = valor;
		return true;
	}

	else{
		return false;
	}
}

bool Ruleta::setBola(int bola){
	if ( (bola>=0)&&(bola<=36)  ){
		bola_ = bola;
		return true;
	}

	else{
		return false;
	}
}

bool Ruleta::addJugador(Jugador j){

	list <Jugador>::iterator i;

	for (i=jugadores_.begin(); i!= jugadores_.end(); i++){
		if ( j.getDNI() == (*i).getDNI() ){
			return false;
		}
	}

	jugadores_.push_back(j);

	string nombre= (j.getDNI()+".txt");

	ofstream fichero(nombre.c_str(), ios::app);
	if (fichero.fail()){
		cout<<"Error al abrir el fichero binario"<<endl;
		exit(-1);
	}


	fichero.close();
	return true;
}

int Ruleta::deleteJugador(string DNI){
	list <Jugador>::iterator i;

	if(jugadores_.size()==0){
		return -1;
	}

	for(i=jugadores_.begin(); i!= jugadores_.end(); i++){
		if (DNI == (*i).getDNI() ){
			jugadores_.erase(i);
			return 1;
		}
	}

	return -2;

}

int Ruleta::deleteJugador(Jugador j){
	list <Jugador>::iterator i;

	if(jugadores_.size()==0){
		return -1;
	}

	for(i= jugadores_.begin(); i!=jugadores_.end(); i++){
		if(j.getDNI() == (*i).getDNI()){
			jugadores_.erase(i);
			return 1;
		}
	}

	return -2;
}

void Ruleta::escribeJugadores(){
	ofstream fichero("jugadores.txt");

	if(fichero.fail()){
		cout<<"Error al crear el fichero de texto"<<endl;
		exit(-1);
	}

	list <Jugador>::iterator i;

		for(i= jugadores_.begin(); i!=jugadores_.end(); i++){

			if( ((*i).getDNI()=="")||((*i).getCodigo()== "")  ){
				cout<<"No se pueden estar en balco ni el DNI ni el codigo"<<endl;
				exit(-1);
			}

			fichero << (*i).getDNI() <<","<< (*i).getCodigo() <<","<< (*i).getNombre() <<","<< (*i).getApellidos() <<","<< (*i).getDireccion() <<","<< (*i).getLocalidad() <<","<< (*i).getProvincia() <<","<< (*i).getPais() <<","<< (*i).getDinero() <<endl;

		}

	fichero.close();
}

void Ruleta::leeJugadores(){

	string nombre_fichero= "jugadores.txt";

	ifstream fichero(nombre_fichero.c_str());
	if (fichero.fail()){
		cout<<"Error al abrir el fichero de texto"<<endl;
		exit(-1);
	}

	string DNI, codigo, nombre, apellidos, direccion, localidad, provincia, pais, dinero;
	int n_dinero;

	jugadores_.clear();
	Jugador j(DNI, codigo);

		while( !fichero.eof() ){
			getline(fichero, DNI, ',');

			if(DNI.empty()){
				break;
			}

			j.setDNI(DNI);

			getline(fichero, codigo, ',');
			j.setCodigo(codigo);

			getline(fichero, nombre, ',');
			j.setNombre(nombre);

			getline(fichero, apellidos, ',');
			j.setApellidos(apellidos);

			getline(fichero, direccion, ',');
			j.setDireccion(direccion);

			getline(fichero, localidad, ',');
			j.setLocalidad(localidad);

			getline(fichero, provincia, ',');
			j.setProvincia(provincia);

			getline(fichero, pais, ',');
			j.setPais(pais);

			getline(fichero, dinero);
			n_dinero= atoi(dinero.c_str());
			j.setDinero(n_dinero);

			jugadores_.push_back(j);
		}

	fichero.close();

}

void Ruleta::giraRuleta(){
	srand(time (NULL));
	bola_=(rand()%36)+1;
}

void Ruleta::getPremios(){

	list <struct Apuesta> apuesta;
	list <Jugador>::iterator it1;
	list <struct Apuesta>::iterator it2;

	for (it1= jugadores_.begin(); it1!= jugadores_.end(); it1++){

		(*it1).setApuestas();
		apuesta=(*it1).getApuestas();
		int dinero=(*it1).getDinero();

		for( it2= apuesta.begin(); it2!= apuesta.end(); it2++){

			if( (*it2).tipo == 1){
				apuestaSencilla(*it2, dinero);
			}

			if( (*it2).tipo == 2){
				apuestaRojoNegro(*it2, dinero);
			}

			if( (*it2).tipo == 3){
				apuestaParImpar(*it2, dinero);
			}

			if( (*it2).tipo == 4){
				apuestaAltoBajo(*it2, dinero);
			}

		}

		(*it1).setDinero(dinero);


	}

}

void Ruleta::apuestaSencilla(struct Apuesta p, int &dinero){
	int valor= atoi ( (p.valor).c_str());
	if (valor == bola_){
		dinero = dinero + p.cantidad*35;
		banca_ = banca_-p.cantidad*35;
	}

	else {
		dinero = dinero-p.cantidad;
		banca_ = banca_+p.cantidad;
	}
}

void Ruleta::apuestaRojoNegro(struct Apuesta p, int &dinero){
	string valor= p.valor;
	int bola= bola_;
	
	if ( (bola_!=0)&&(valor == color(bola)) ){
		dinero= dinero+p.cantidad;
		banca_= banca_-p.cantidad;
	}

	else{
		dinero= dinero-p.cantidad;
		banca_= banca_+p.cantidad;
	}

}

string Ruleta::color(int bola){

	switch (bola){

		case 1:
				return "rojo";
		break;

		case 3:
				return "rojo";
		break; 

		case 5:
				return "rojo";
		break;

		case 7:
				return "rojo";
		break; 

		case 9:
				return "rojo";
		break;

		case 12:
				return "rojo";
		break;

		case 14:
				return "rojo";
		break; 

		case 16:
				return "rojo";
		break;

		case 18:
				return "rojo";
		break;

		case 19:
				return "rojo";
		break;

		case 21:
				return "rojo";
		break;

		case 23:
				return "rojo";
		break; 

		case 25:
				return "rojo";
		break;

		case 27:
				return "rojo";
		break;

		case 30:
				return "rojo";
		break;

		case 32:
				return "rojo";
		break;

		case 34:
				return "rojo";
		break;

		case 36:
				return "rojo";
		break;

		default:
			return "negro";

	}

}

void Ruleta::apuestaParImpar(struct Apuesta p, int &dinero){
	string valor = p.valor;
	int bola = bola_;

	if ( (bola_!=0)&&(valor==par_impar(bola))){
		dinero= dinero+p.cantidad;
		banca_= banca_-p.cantidad;
	}

	else{
		dinero= dinero-p.cantidad;
		banca_= banca_+p.cantidad;
	}

}

string Ruleta::par_impar(int bola){
	if(bola%2==0){
		return "par";
	}
	else{
		return "impar";
	}
}

void Ruleta::apuestaAltoBajo(struct Apuesta p, int &dinero){
	string valor = p.valor;
	int bola = bola_;

	if ( (bola_!=0)&&(valor == alto_bajo(bola)) ){
		dinero= dinero+p.cantidad;
		banca_= banca_-p.cantidad;
	}

	else{
		dinero= dinero-p.cantidad;
		banca_= banca_+p.cantidad;
	}
}

string Ruleta::alto_bajo(int bola){
	if( (bola>=1)&&(bola<=18) ){
		return "bajo";
	}

	else{
		return "alto";
	}

}