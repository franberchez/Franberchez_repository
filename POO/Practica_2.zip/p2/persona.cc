#include <iostream>
#include <string>
#include "persona.h"

Persona::Persona(std::string dni, std::string nombre, std::string apellidos, int edad, std::string direccion, std::string localidad, std::string provincia, std::string pais)
{
	DNI_=dni;
	nombre_= nombre;
	apellidos_= apellidos;
	edad_= edad;
	direccion_ = direccion;
	localidad_ = localidad;
	provincia_ = provincia;
	pais_ = pais;
}

bool Persona::setEdad(int num){
	if (num<0){
		return false;
	}

	else{
		edad_=num;
		return true;
	}
}

bool Persona::mayor(){
	if (edad_>=18){
		return true;
	}

	else{
		return false;
	}
}