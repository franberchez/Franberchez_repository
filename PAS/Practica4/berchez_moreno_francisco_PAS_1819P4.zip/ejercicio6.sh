#!/bin/bash

if [ $# -ne 1 ];
then 
	echo -e "No se ha recibido una cadena de texto"
	exit 1
fi


while read x
do
	numero_grupo=$(echo $x | egrep "$1$" | sed -r 's/(.*):(.*):(.*):(.*):(.*):(.*):(.*)/\4/g')
	usuario=$(echo $x | egrep "$1$" | sed -r 's/(.*):(.*):(.*):(.*):(.*):(.*):(.*)/\1/g')

	if [ "$(who -u | egrep "$usuario")" ];
	then
		echo $x | egrep "$1$" | sed -r  's/^(.*):(.*):(.*):(.*):(.*):(.*):(.*)$/=========\nLogname: \1\n->UID: \3\n->Grupo: \1\n->GID: \4\n->gecos: \5\n->Home: \6\n->Shell por defecto: \7\n->Logueado: 1\n/g'
	else
		echo $x | egrep "$1$" | sed -r  's/^(.*):(.*):(.*):(.*):(.*):(.*):(.*)$/=========\nLogname: \1\n->UID: \3\n->Grupo: \1\n->GID: \4\n->gecos: \5\n->Home: \6\n->Shell por defecto: \7\n->Logueado: 0\n/g'
	fi
done < /etc/passwd