#!/bin/bash

# El script tiene que ller de la carpeta /proc/ e imprimir una serie de parametros indicados en el ejercicio

# Hay una serie de ficheros que son los que debere consultar /proc/cpuinfo, /proc/mounts, /proc/partitions

# Dicho script no recibe nada por lineas de argumentos

# De la carpeta /proc/cpuinfo vamos a sacar los parametros de 
# Modelo del procesador, que viene determinado por el campo model name
# y los megahercios que vienen determinados con el campo cpu MHz
# el tamaño de la cache que viene determinado por el campo cache size
# el identificador del vendedor que viene determinado en el campo vendor_id

# Modelo del procesador
cat /proc/cpuinfo | sed -n -r 's/model name[[:blank:]]*: (.*)/Modelo de procesador: \1/gp' | head -1
# Con head -1 solo me lo muestra una vez

# Megahercios
cat /proc/cpuinfo | sed -n -r 's/cpu MHz[[:blank:]]*: (.*)/Megahercios: \1/gp' | head -1

# Numero de hilos
echo "Número de hilos de ejecución: $(cat /proc/cpuinfo | grep -E 'processor[[:blank:]]*: .+' | wc -l)" # creo que son los siblings y para eso lo hago mas facil

# Tamaño de la cache
cat /proc/cpuinfo | sed -n -r 's/cache size[[:blank:]]*: (.*)/Tamaño de cache: \1/gp' | head -1

# Identificador del vendedor
cat /proc/cpuinfo | sed -n -r 's/vendor_id[[:blank:]]*: (.*)/ID vendedor: \1/gp' | head -1

# De la carpeta /proc/mounts

echo "Puntos de montaje:"

# Al hacer en el terminal cat /proc/mounts vamos a encontrar un monton de texto y de el deberemos de sacar
# una serie de conclusiones, como son que la primera palabra que nos aparece antes de un espacio es el dispositivo
# montado, la segunda palabra que nos sale antes de un espacio es el punto de montaje donde hemos montado ese dispositivo
# y la tercera palabra que hay antes de un espacio es el tipo de dispositivo montado, por eso solo mostramos esas 3 palabras
# si contamos las palabras que tenemos separadas por espacios, veremos que tenemos en total 6, por eso pongo 6 .* separados por
# espacios, para hacer referencia a cada una de ellas y asi evitarme de problematicas a la hora de crear una expresion regular

cat /proc/mounts | sed -r 's/(.*) (.*) (.*) (.*) (.*) (.*)/-> Punto de montaje: \2, Dispositivo: \1, Tipo de dispositivo: \3/g' | sort -r -k2 # porque la segunda columna es el punto de montaje

# De la carpeta /proc/partitions

echo "Particiones y numero de bloques:"

cat /proc/partitions | sed -r '1,2 d; s/(.*) (.*) (.*) (.*)/-> Particion: \4, Numero Bloques: \3/g' | sort -r -k4 # como me dice por orden alfabetico, la unica forma es ordenarlo por el nombre