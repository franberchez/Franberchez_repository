#!/bin/bash

if [ $# -ne 1 ];
then
	echo "No se ha recibido ningun fichero como argumento"
	exit 1
fi

if [ ! -f $1 ];
then
	echo "El argumento recibido no es un fichero"
	exit 1
fi

# Primero tenemos que mostrar los ficheros ocultos de la carpeta $HOME ordenados por el numero de caracteres

for x in $(ls -a $HOME | egrep '^\.') # aqui solo cogemos todos los archivos que tengan un punto al principio
do
	num_caracteres=$(echo $x | wc -m)
	echo "$x $num_caracteres"
done | sort -k2 -n | egrep -o '^\..* ' # aqui cogemos todos los archivos que tienen . y algo despues y luego espacio, para no mostrar el numero de caracteres

# Hacer una copia del fichero series.txt de nombre series.txt.sinLineasVacias esto lo haremos siempre que el fichero exista

echo "=========="
echo "El fichero a procesar es $1"

# Tengo que hacer alguna comprobacion que me pide el ejercicio

cat $1 | sed '/^$/d' > $1.sinLineasVacias

echo "El fichero sin lı́neas vacı́as se ha guardado en $1.sinLineasVacias"
echo "=========="

# Vamos a listar por pantalla todos los procesos que se estan ejecutando en este momento.
# Para cada proceso se mostrará su PID, la hora en la que se lanzo y el nombre del fichero ejecutable

echo "Listado de los usuarios ejecutados por el usuario $USER:"

ps -u $USER -o pid,start,comm | sed -r -n 's/([0-9]+) ([0-9]+:[0-9]+:[0-9]+) (.*)/PID: "\1" Hora: "\2" Ejecutable: "\3"/gp'