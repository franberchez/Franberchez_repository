#!/bin/bash

# Este ejercicio 1 se basa en un uso intensivo del comando grep

if [ $# -ne 1 ];
then
	echo "No se introdujo fichero que se quiere leer"
	exit 1
fi

if [ ! -f "$1" ];
then
	echo "El argumento recibido no es un fichero"
	exit 1
fi

echo "*******"
echo "1) Líneas con la duración de las películas:"
cat $1 | egrep '[12]hr[ ]([0-5][0-9]|60)min'

echo "*******"
echo "2) Lı́neas con el paı́s de las pelı́culas:"
#cat $1 | egrep '(0[1-9]|[12][0-9]|3[01])(\/)(0[1-9]|1[0-2])\2([0-2][0-9]{3})[ ](\-[A-Z][a-z]+\-)'
#cat $1 | egrep '\-[A-Z][a-z]+\-'
cat $1 | egrep '\-.+\-' # Busco las palabras que hay entre guiones con el punto indico que empieza por un caracter cualquiera y el + para que haya uno o varios

echo "*******"
echo "3) Solo el paı́s de las pelı́culas:"
cat $1 | egrep -o '\-.+\-' | egrep -o '[^\-].+[^\-]' # Este ultimo egrep es para que no me muestre los guiones
# cat $1 | egrep -o '[ ]\-.+\-' En este caso lo muestra bien pero te deja los guiones

echo "*******"
pelicula_2016=$(cat $1 | egrep '(0[1-9]|[12][0-9]|3[01])(\/)(0[1-9]|1[0-2])(\/)2016' | wc -l)
pelicula_2017=$(cat $1 | egrep '(0[1-9]|[12][0-9]|3[01])(\/)(0[1-9]|1[0-2])(\/)2017' | wc -l)
echo "4) Hay $pelicula_2016 pelı́culas del 2016 y $pelicula_2017 pelı́culas del 2017"

echo "*******"
echo "5) Eliminar lı́neas vacı́as:"
cat $1 | egrep '.' # Como el punto es cualquier caracter muestra todas las lineas en las que hay algo

echo "*******"
echo "6) Lı́neas que empiezan la letra E (con o sin espacios antes):"
cat $1 | egrep '^[ ]*E' # Este no tengo muy claro si esta correcto

echo "*******"
echo "7) Lı́neas que contienen d, l o t, una vocal y la misma letra:"
cat $1 | egrep '([dlt])[aeiou]\1' # A mi lo de la misma letra no me queda muy claro

echo "*******"
echo "8) Lı́neas que contienen ocho aes o más:"
cat $1 | egrep -o '(.*[Aa].*){8}' # No tengo muy claro como ha salido, revisarlo

echo "*******"
echo "9) Lı́neas que terminan con tres puntos y no empiezan por espacio:"
cat $1 | egrep -o '^([^ ]).*(\.\.\.)$'
# Con el ^ indico que me coja el principio de linea y con [^ ] que no sea un espacio
# $ es el final de linea

echo "*******"
echo "10) Mostrar entre comillas las vocales con tilde:"
cat $1 | sed -r 's/([áéíóúÁÉÍÓÚ])/"\1"/g'