#!/bin/bash

# A partir de un fichero de texto con una serie de direcciones IP (IPs.txt), haz un script que
# sea capaz de hacer ping a cada una de dichas direcciones y de imprimirlas en orden según lo que
# tardan en contestar (por ejemplo, para configurar el servidor DNS más adecuado). El nombre
# del fichero con las IPs se pasará como argumento a la lı́nea de comandos. El segundo argumento
# será el número de segundos que deben de pasar antes de dar por muerto al servidor. Deberás
# investigar sobre el comando ping para configurarlo de forma que se mande un solo ping. Si la
# máquina a la que envı́a el ping no está activa, el comando ping devolverá un código de error
# distinto de cero al sistema operativo. A continuación, se muestra un ejemplo de la ejecución del
# script (las lı́neas están ordenadas de menor a mayor tiempo de respuesta):

if [ $# -ne 2 ];
then
	echo "Ejecucion: ./ejercicio4.sh <fichero> <segundos>"
	exit 1
fi

if [ ! -f $1 ];
then
	echo "El primer argumento no es un fichero"
	exit 1
fi

if [ $2 -le 0 ];
then
	echo "El numero de segundos debe ser mayor que 0"
	exit 1
fi

touch exito

for x in $(cat $1)
do
	ping -w $2 -c 1 $x > fichero

	if [ $? -eq 0 ];
	then
		cat fichero | sed -r -n 's/(.*) from (.*): (.*) time=(.*) ms/La IP \2 respondio en \4 milisegundos/gp' >> exito
	else
		echo "La IP $x no respondio tras $2 milisegundos" >> fichero_temporal
	fi
done

cat exito | sort -k6 -n
cat fichero_temporal

rm fichero_temporal
rm fichero
rm exito
