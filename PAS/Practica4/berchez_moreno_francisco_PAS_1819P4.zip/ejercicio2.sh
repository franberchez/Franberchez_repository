#!/bin/bash

if [ $# -ne 1 ];
then
	echo "No se introdujo el nombre del fichero"
	exit 1
fi

if [ ! -f $1 ];
then
	echo "El argumneto recibido no es un fichero"
	exit 1
fi

# Utilizando sed, hacer un script que, dado el fichero de texto peliculas.txt, elimine las
# lı́neas vacı́as y los subrayados, extraiga el tı́tulo de la pelı́cula y lo sitúe en una lı́nea indepen-
# diente como “Tı́tulo: XXX” 1 , la fecha de estreno como “|-> Fecha de estreno: XXX”,
# formatee el director y el reparto como “|-> Director: XXX” y “|-> Reparto: XXX” y la
# duración como “|-> Duración: XXX”. El script recibirá el nombre del fichero por la lı́nea de
# comandos.

cat $1 | sed -r -n '/^$/d; /^[=]*$/d; s/(\()(.*\/.*\/.*)(\)) (.+)/|-> Fecha de estreno: \2/gp; s/(Dirigida por) (.+)/|-> Director: \2/gp; s/(Reparto:) (.+)/|-> Reparto: \2/gp; s/([12]hr[ ]([0-5][0-9]|60)min)/|-> Duración: \1/gp; s/(^[^| ].*)/Título: \1/gp'
# s/(\()(.*\/.*\/.*)(\)) (.+)/|-> Fecha de estreno: \2/gp;  Especifico que tengo un numero entre dos parentesis, pero los pongo separados de forma que pueda mostrar solo la fecha de estreno si los parentesis, de ahi el \2
